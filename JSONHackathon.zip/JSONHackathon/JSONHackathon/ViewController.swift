//
//  ViewController.swift
//  JSONHackathon
//
//  Created by Developer on 7/17/18.
//  Copyright © 2018 Dane Olsen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        performQuery(query: "restaurants")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func performQuery(query:String){
        let radius = "1000"
        let apiKey = "AIzaSyDo4eB_-Rf78ywCcttY1CewbrOyDNRhsWs"
        let url = URL(string: "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.375492191953093,-121.91030247864278&radius=\(radius)&type=\(query)&keyword=mexican&key=\(apiKey)")!
        print(url)
        let session = URLSession.shared
        let task = session.dataTask(with: url, completionHandler: {
            data, response, error in
            
            do {
                // Try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] as? NSArray {
                        print("THE RESULTS ARE", results)
                        for locale in results {
                            // cast to dictionary for data extraction
                            //                            self.queryResults.append(locale)
                        }
                    }
                }
            } catch {
                print("Something went wrong")
            }
        })
        // Actually "execute" the task. This is the line that actually makes the request that we set up above
        task.resume()
        print("I happen before the response!")
    }
    
    

}

